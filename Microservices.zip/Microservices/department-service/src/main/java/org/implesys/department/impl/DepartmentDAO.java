/*
 * package org.implesys.department.impl;
 * 
 * import java.util.List;
 * 
 * import org.implesys.department.model.Department;
 * 
 * public interface DepartmentDAO {
 * 
 * public boolean save();
 * 
 * public boolean delete();
 * 
 * public int add(Department dept);
 * 
 * public List<Department> getAllDepartments();
 * 
 * }
 */