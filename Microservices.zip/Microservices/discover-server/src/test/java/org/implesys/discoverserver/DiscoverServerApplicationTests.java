package org.implesys.discoverserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiscoverServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
